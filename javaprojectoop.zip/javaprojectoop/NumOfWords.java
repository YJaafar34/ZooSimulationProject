package javaprojectoop;

public class NumOfWords {
    public static void main(String[] args) {
        String input="Hello, world!";
        int wordCount=countWords(input);
        System.out.println("Number of words: " + wordCount);
    }
    public static int countWords(String str){
        String cleaned = str.replaceAll("[\\p{Punct}]", " ");
        String[] words=cleaned.trim().split("\\s+");
        return words.length;
    }
}


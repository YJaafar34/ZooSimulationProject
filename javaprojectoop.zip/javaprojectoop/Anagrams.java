package javaprojectoop;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class Anagrams {
    public static void main(String[] args) {

        String str1 = "listen";
        String str2 = "silent";

        System.out.println("Are '" + str1 + "' and '" + str2 + "' anagrams?");
        System.out.println(isAnagram(str1, str2)); // true

        // More examples
        System.out.println(isAnagram("hello", "world"));  // false
        System.out.println(isAnagram("evil", "vile"));    // true
    }

    public static boolean isAnagram(String str1, String str2) {
        // Remove spaces and convert to lowercase for better comparison
        str1 = str1.replaceAll("\\s", "").toLowerCase();
        str2 = str2.replaceAll("\\s", "").toLowerCase();

        // If lengths are different, they can't be anagrams
        if (str1.length() != str2.length()) {
            return false;
        }

        // Convert to char arrays and sort
        char[] charArray1 = str1.toCharArray();
        char[] charArray2 = str2.toCharArray();

        Arrays.sort(charArray1);
        Arrays.sort(charArray2);

        // Check if sorted arrays are identical
        return Arrays.equals(charArray1, charArray2);
    }

}




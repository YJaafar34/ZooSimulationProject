package javaprojectoop;

import java.util.ArrayList;
import java.util.LinkedHashSet;

public class DuplicatesFromArrayList {
    public static void main(String[] args) {
        ArrayList<String> list = new ArrayList<>();
        list.add("apple");
        list.add("banana");
        list.add("apple");
        list.add("orange");

        // Remove duplicates
        LinkedHashSet<String> set = new LinkedHashSet<>(list);
        ArrayList<String> uniqueList = new ArrayList<>(set);

        System.out.println("List without duplicates: " + uniqueList);
    }
}


package javaprojectoop;

import java.util.LinkedHashMap;
import java.util.Map;

public class FirstNonRepeating {
    public static void main(String[] args) {
        String str = "abracadabra";
        Character result = findFirstNonRepeating(str);

        System.out.println("String: \"" + str + "\"");
        if (result != null) {
            System.out.println("First non-repeating character: '" + result + "'");

        } else {
            System.out.println("No non-repeating character found");
        }
        System.out.println(findFirstNonRepeating("swiss"));
        System.out.println(findFirstNonRepeating("aabb"));
        System.out.println(findFirstNonRepeating("java"));
    }

    public static Character findFirstNonRepeating(String str) {
        Map<Character, Integer> charcount = new LinkedHashMap<>();

        for (Map.Entry<Character, Integer> entry : charcount.entrySet()) {
            if (entry.getValue() == 1) {
                return entry.getKey();
            }
        }
        return null;
    }

}



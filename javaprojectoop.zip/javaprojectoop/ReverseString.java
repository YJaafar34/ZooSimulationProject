package javaprojectoop;

public class ReverseString {
    public static void main(String[] args) {
        String input="Hello";
        String reversed=reversedString(input);

        System.out.println("Original String: " + input);
        System.out.println("Reversed string: " + reversed);
    }

    public static String reversedString(String str) {
       return new StringBuilder(str).reverse().toString();

    }
}

package zoo;

    public interface AnimalBehavior{
        void eat();
        void sleep();
        void makeSound();
}

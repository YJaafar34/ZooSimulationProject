package zoo;

public abstract class Mammal extends Animal{
    public Mammal(String name, int age){
        super(name, age);
    }

    public abstract void makeSound();
    public abstract void displayInformation();

}

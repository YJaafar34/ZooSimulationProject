package zoo;

public class Elephant extends Mammal{
    public Elephant(String name, int age){
        super(name, age);
    }
    public void eat() {
        System.out.println(name + " the elephant is eating grass and leaves.");

}

    public void makeSound() {
        System.out.println(name + " trumpets loudly!");
    }
    public void displayInformation() {
        System.out.println("Elephant - Name: " + name + ", Age: " + age);
    }
}

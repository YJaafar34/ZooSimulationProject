package zoo;

public class Lion extends Mammal {
    public Lion(String name, int age) {
        super(name, age);
    }

    public void eat() {
        System.out.println(name + " the lion is eating meat.");
    }

    public void makeSound() {
        System.out.println(name + " roars loudly!");
    }

    public void displayInformation() {
        System.out.println("Lion - Name: " + name + ", Age: " + age);

    }
}

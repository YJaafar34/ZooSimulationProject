package zoo;

public class ZooSimulation {
    public static void main(String[] args) {

        Animal[] zoo = {
                new Lion("Simba", 5),
                new Elephant("Dumbo", 10),
                new Parrot("Kiwi", 2),
                new Eagle("Sky", 4)
        };

        for (Animal animal : zoo) {
            animal.displayInformation();
            animal.eat();
            animal.makeSound();
            animal.sleep();
            System.out.println("-----------------------------");
        }
    }
}
